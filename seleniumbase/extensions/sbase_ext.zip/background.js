var init = function () {
    chrome.runtime.onInstalled.addListener(function (object) {
        chrome.notifications.create("T_" + Date.now(), {
            type: 'basic',
            iconUrl: 'images/sbase_icon.png',
            title: 'SBase Extension',
            message: 'SBase Extension',
            priority: 2
        });
    });
    chrome.browserAction.onClicked.addListener(function (tab) { });
    chrome.webNavigation.onCompleted.addListener(function (details) { });
    chrome.tabs.onActivated.addListener(function (activeInfo) { });
};
init();
